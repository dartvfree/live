export default {
    debug: __DEBUG__
};
