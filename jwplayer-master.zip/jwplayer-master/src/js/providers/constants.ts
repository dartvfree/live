export const MetaBufferLength = 1;
export const MinBufferLength = MetaBufferLength + 1;
export const MaxBufferLength = 25;
