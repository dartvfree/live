const video = __HEADLESS__ ? null : document.createElement('video');
export default video;
