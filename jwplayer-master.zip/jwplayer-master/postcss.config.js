module.exports = {
    plugins: [
        require('postcss-easing-gradients'),
        require('autoprefixer')
    ]
};
