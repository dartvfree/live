export const defaultConfig = {
    autostart: true,
    width: '100%',
    aspectratio: '16:9',
    playlist: '//cdn.jwplayer.com/v2/playlists/bEhVQYdb',
};
