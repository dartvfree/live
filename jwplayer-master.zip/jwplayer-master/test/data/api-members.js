import _ from 'utils/underscore';

export default {
    version: '',
    id: '',
    uniqueId: 0,
    _qoe: {},
    _events: {},
    Events: function() {},
    utils: {},
    _: _,
    plugins: {}
};
