# Video.js® Collaborator Guide

Please refer to: <https://github.com/videojs/admin/blob/main/COLLABORATOR_GUIDE.md>
