# Video.js® Code of Conduct

Please refer to: <https://github.com/videojs/admin/blob/main/CODE_OF_CONDUCT.md>
