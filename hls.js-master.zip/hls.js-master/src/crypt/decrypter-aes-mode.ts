export const enum DecrypterAesMode {
  cbc = 0,
  ctr = 1,
}
