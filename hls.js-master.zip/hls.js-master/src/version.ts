export const version = __VERSION__;
